MigratoryData Client SDK for Java

Version:     6.0
Build:       20210520

DOCUMENTATION
-------------

Please refer to the Developer's Guide and the Reference Manual of the
MigratoryData Client SDK for Java located at:

https://migratorydata.com/documentation.html

SAMPLE
-------

We provide a sample client application in the folder `examples`. In order to
learn how to build a client application, please refer to the README.txt file
of the sample client application.
